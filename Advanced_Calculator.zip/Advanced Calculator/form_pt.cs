﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Advanced_Calculator
{
    public partial class form_pt : Form
    {
      //  private NoteViewModel _viewModel;
        public form_pt()
        {
            InitializeComponent();
         //   _viewModel = new NoteViewModel();
            BindData();
        }

        private void BindData()
        {
            //dgvNotes.DataSource = _viewModel.Notes;
            //txtTitle.DataBindings.Add("Text", _viewModel, "Title");
            //txtContent.DataBindings.Add("Text", _viewModel, "Content");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           // _viewModel.SaveNote();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
          //  _viewModel = new NoteViewModel();
            BindData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
          //  _viewModel.DeleteNote();
        }
    }

        
 
}
